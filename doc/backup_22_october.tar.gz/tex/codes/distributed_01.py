from t100.components.components import *
from t100.simtool.distributed_env import Environment

import random
import time
import sys

def creation_expression(timestamp):
    return 1.0/1000

def execution_expression(timestamp):
    return 10 + random.randint(-5,+5)

if  __name__=='__main__':
    ip,port = '192.168.0.11',11111
    process = QueuedProcess()
    source = Source(output=process,
                    creation_tax_expression=creation_expression,
                    execution_time_expression=execution_expression,)
    cfg = open('distributed_01.json').read()
    env = Environment(ip, port, cfg, verbose=True)
    env.populate([source,process])
    env.start_simulation(untill=1000)
