from t100.core.simulator import Simulator
from t100.core.base_components import *

def execution_time_expression(timestamp): 
    return 60 + random.randint(-30,+30)

def ct_1(timestamp): 
    return 1.0 / (60 * 5)

def ct_2(timestamp): 
    return 5.0 / (60 * 5)

if __name__=='__main__':
    steps_number = 60*60
    acc1 = acc2 = 0
    q1 = Queue()
    q2 = Queue()
    s1 = Source(output=q1, 
                creation_tax_expression=ct_1, 
                execution_time_expression=execution_time_expression)
    s2 = Source(output=q2, 
                creation_tax_expression=ct_2, 
                execution_time_expression=execution_time_expression)
    p = Process(inputs=[q1,q2])
    simul = Simulator(components=[q1,q2,s1,s2,p], )
    simul.run(untill=steps_number)
    q1_size = len(simul.components['queue'][0])
    q2_size = len(simul.components['queue'][1])
    print q1_size
    print q2_size

    acc1 = acc2 = 0
    q1 = Queue()
    q2 = Queue()
    s1 = Source(output=q1, 
                creation_tax_expression=ct_1, 
                execution_time_expression=execution_time_expression)
    s2 = Source(output=q2, 
                creation_tax_expression=ct_2, 
                execution_time_expression=execution_time_expression)
    p1 = Process(inputs=[q1,q2])
    p2 = Process(inputs=[q1,q2])
    simul = Simulator(components=[q1,q2,s1,s2,p1,p2])
    simul.run(untill=steps_number)
    q1_size = len(simul.components['queue'][0])
    q2_size = len(simul.components['queue'][1])
    print q1_size
    print q2_size
