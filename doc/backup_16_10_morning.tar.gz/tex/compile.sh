
latex monografia.tex
bibtex monografia
pdflatex monografia.tex
pdflatex monografia.tex
